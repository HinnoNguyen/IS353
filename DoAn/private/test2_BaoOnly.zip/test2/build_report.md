# Báo cáo sinh test2 (giữ kín)

- Tổng: **175 câu**; sha256 (canonical_hash): `46780d6aabb01eddbd4d9666385097d3ca6b5ffff89429659f4b7dff575becf1`

| Loại | Câu thường | Câu zero |
|---|---|---|
| lookup | 30 | 5 |
| aggregation | 30 | 5 |
| multi_hop | 30 | 5 |
| path | 30 | 5 |
| temporal | 30 | 5 |

## Nhật ký lọc theo template

```
LK-12 zero: giữ 2/2 (ứng viên 2560), loại -
LK-14 zero: giữ 3/3 (ứng viên 243), loại {'old_entity': 1}
AG-11 zero: giữ 2/2 (ứng viên 4082), loại -
AG-13 zero: giữ 2/2 (ứng viên 417), loại {'old_entity': 2}
AG-15 zero: giữ 1/1 (ứng viên 61), loại -
MH-12 zero: giữ 2/2 (ứng viên 526), loại -
MH-13 zero: giữ 1/1 (ứng viên 35), loại -
MH-14 zero: giữ 2/2 (ứng viên 427), loại {'old_entity': 4}
PA-11 zero: giữ 1/1 (ứng viên 43), loại -
PA-12 zero: giữ 1/1 (ứng viên 43), loại {'duplicate_name': 1}
PA-13 zero: giữ 1/1 (ứng viên 9), loại {'duplicate_name': 1}
PA-15 zero: giữ 2/2 (ứng viên 1190), loại {'old_entity': 1, 'not_zero': 1}
TM-11 zero: giữ 2/2 (ứng viên 291), loại {'old_entity': 3}
TM-12 zero: giữ 1/1 (ứng viên 4526), loại {'old_entity': 1}
TM-14 zero: giữ 1/1 (ứng viên 119), loại {'old_entity': 1}
TM-15 zero: giữ 1/1 (ứng viên 10144), loại -
LK-11 main: giữ 6/6 (ứng viên 1528), loại {'too_many_rows': 4, 'duplicate_name': 1, 'old_entity': 22}
LK-12 main: giữ 6/6 (ứng viên 12009), loại {'old_entity_in_title': 5, 'empty': 5, 'too_many_rows': 1}
LK-13 main: giữ 6/6 (ứng viên 3313), loại {'old_entity': 1}
LK-14 main: giữ 6/6 (ứng viên 1336), loại {'empty': 1}
LK-15 main: giữ 6/6 (ứng viên 1528), loại {'old_entity': 70, 'duplicate_name': 1}
AG-11 main: giữ 6/6 (ứng viên 4182), loại -
AG-12 main: giữ 6/6 (ứng viên 52), loại {'empty': 4, 'check_failed': 1}
AG-13 main: giữ 6/6 (ứng viên 1347), loại {'old_entity': 47, 'used_in_test2': 2, 'zero': 4, 'duplicate_name': 1}
AG-14 main: giữ 6/6 (ứng viên 151), loại -
AG-15 main: giữ 6/6 (ứng viên 111), loại {'zero': 15, 'old_entity': 7, 'used_in_test2': 3}
MH-11 main: giữ 6/6 (ứng viên 1328), loại {'old_entity': 30, 'duplicate_name': 1}
MH-12 main: giữ 6/6 (ứng viên 14342), loại {'old_entity': 59, 'used_in_test2': 6, 'duplicate_name': 1}
MH-13 main: giữ 6/6 (ứng viên 1365), loại {'old_entity': 42, 'check_failed': 3, 'too_many_rows': 8, 'used_in_test2': 3, 'duplicate_name': 1}
MH-14 main: giữ 6/6 (ứng viên 1357), loại {'old_entity': 36, 'used_in_test2': 3, 'duplicate_name': 1, 'empty': 1}
MH-15 main: giữ 6/6 (ứng viên 1155), loại {'old_entity': 15, 'duplicate_name': 1, 'used_in_test2': 3}
PA-11 main: giữ 6/6 (ứng viên 843), loại {'check_failed': 30, 'used_in_test2': 38, 'duplicate_name': 3}
PA-12 main: giữ 6/6 (ứng viên 53), loại {'duplicate_name': 2, 'used_in_test2': 6}
PA-13 main: giữ 6/6 (ứng viên 227), loại {'old_entity': 19, 'check_failed': 1, 'used_in_test2': 3}
PA-14 main: giữ 6/6 (ứng viên 1366), loại {'used_in_test2': 33, 'duplicate_name': 4, 'check_failed': 2}
PA-15 main: giữ 6/6 (ứng viên 5952), loại {'empty': 685, 'used_in_test2': 3412, 'duplicate_name': 221, 'old_entity': 1704, 'not_preferred': 161}
TM-11 main: giữ 6/6 (ứng viên 2617), loại {'old_entity': 47, 'used_in_test2': 9, 'duplicate_name': 3}
TM-12 main: giữ 6/6 (ứng viên 12060), loại {'old_entity': 41, 'used_in_test2': 6, 'duplicate_name': 3}
TM-13 main: giữ 6/6 (ứng viên 1347), loại {'old_entity': 46, 'duplicate_name': 2, 'check_failed': 1, 'used_in_test2': 4}
TM-14 main: giữ 6/6 (ứng viên 1357), loại {'old_entity': 24, 'used_in_test2': 3}
TM-15 main: giữ 6/6 (ứng viên 2913), loại -
```
