# Xây dựng tập đánh giá độc lập test2 (nháp phần báo cáo cuối kỳ – Hương)

**Lý do.** Tập test cũ không còn độc lập: một số quy ước của thành phần (A) được bổ sung sau khi nhóm đã xem lỗi của B1 trên test. Vì vậy nhóm xây thêm tập **test2**. Test2 do thành viên không tham gia phát triển hệ thống xây dựng và được giữ kín cho tới khi pipeline bị khóa (tag `freeze-cuoi-ky`). Tập test cũ từ đây chỉ dùng để chẩn đoán.

**Thiết kế.** Test2 có **25 template mới**, mỗi loại câu 5 template. Mỗi template khác các template cũ về cấu trúc truy vấn, không chỉ khác cách diễn đạt. Có hai cách khác: (i) dùng quan hệ hoặc thuộc tính chưa xuất hiện trong bộ cũ, như `HAS_MODERATOR`, `Forum-HAS_TAG`, thuộc tính trên cạnh `WORK_AT.workFrom` và `LIKES.creationDate`, hay `REPLY_OF`; (ii) dùng hình dạng truy vấn mới, như trả về các node nằm giữa đường đi ngắn nhất hoặc đếm người ở khoảng cách đúng 3. Mỗi loại có ít nhất một template khó hơn:

- phủ định: AG-15, MH-14;
- so sánh hai thực thể: LK-15, PA-14, TM-14;
- gộp trên kết quả gộp: AG-14;
- đường ngắn nhất có ràng buộc trên mọi node: PA-15;
- điều kiện thời gian trên cạnh: TM-11.

Mỗi template sinh **6 câu**, tổng cộng 150 câu. Nhóm thêm **25 câu có đáp án đúng là rỗng hoặc 0**, mỗi loại 5 câu, đánh dấu `"subset": "zero"`. Các câu này được chọn từ dữ liệu thật, ví dụ forum chưa có thành viên, thành phố không có trường đại học, quốc gia mà mọi cư dân đều đã viết bài. Chúng dùng để đo tỉ lệ thành phần (D) "sửa nhầm" một câu vốn đúng. Tổng cộng test2 có **175 câu**.

**Một câu một cách hiểu.** Câu hỏi được viết theo `QA_GUIDELINE.md` và danh sách lỗi ngôn ngữ của template cũ do Ân tổng hợp:

- Nói rõ "posts (not counting comments)", "friendship links" và có tính chính người được hỏi hay không.
- Mọi câu kết thúc bằng dấu hỏi. Tên viết tự nhiên, không có `_`. Có mạo từ *the* trước các quốc gia như *the Netherlands*, *the Philippines*.
- Câu "most" có `check` để loại trường hợp đồng hạng ở vị trí đầu. AG-12 chỉ dùng category lá, để không phải hỏi có tính category con hay không.
- PA-11 chỉ giữ cặp người có **duy nhất** một đường ngắn nhất.

Bộ lọc tự động loại câu có:

- đáp án quá 20 dòng hoặc có dòng trùng nhau (hai thực thể trùng tên);
- gold chạy quá 10 giây;
- người được hỏi trùng họ tên với người khác.

**Giữ độc lập.**

- Test2 được xây trong thư mục `DoAn/private/`. Thư mục này không đưa lên git. Người xây không đọc prompt hay kết quả của hệ thống.
- Mọi giá trị tham số (tên, họ, tag, thành phố, quốc gia, forum...) đều **không trùng** với dev, dev_para, dev_zero, test cũ, câu pilot và tên mẫu trong prompt (A). Phép so sánh không phân biệt hoa thường, `_` hay dấu cách. Kết quả là chỉ còn 398/1.528 người được dùng.
- Mỗi thực thể chỉ xuất hiện trong một câu của test2.
- Việc sinh câu dùng seed cố định: chạy lại cho ra cùng một tập (SHA-256 `46780d6a…`).
- Sau khi khóa pipeline, Ân và Vũ đọc mù: họ chỉ nhận câu hỏi, đã xáo thứ tự, không kèm gold. Câu nào bị hiểu khác ý gold thì được viết lại (xem `results/audit/doc_mu_test2.md`). Khôi chạy kiểm tra rò rỉ trên prompt đã khóa. Sau đó Bảo commit `test2.json` kèm mã băm.

**Giới hạn.**

- Trong dữ liệu, ràng buộc "chỉ đi qua người cùng quốc gia" của PA-15 không làm đường đi dài hơn ở bất kỳ cặp nào. Vì vậy PA-15 ưu tiên các cặp có đường dài ít nhất 3 cạnh, nhưng một model bỏ qua ràng buộc vẫn có thể trả lời đúng.
- Mọi người có bạn đều nằm trong cùng một thành phần liên thông. Do đó câu path rỗng/0 chỉ đến từ người không có bạn nào hoặc từ đường đi bị ràng buộc.
