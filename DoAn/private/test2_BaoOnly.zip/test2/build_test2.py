"""T58 – Sinh test2 (Hương). GIỮ KÍN: thư mục DoAn/private/ không được push.

Template: private/test2/templates/<loại>.json, cùng định dạng eval/templates/ (xem eval/generate_questions.py),
thêm trường tùy chọn "zero": {count, note, candidates[, check]} để sinh câu có đáp án đúng là rỗng hoặc 0,
và "prefer" (Cypher trả true): ưu tiên ứng viên thỏa điều kiện, thiếu thì lấy bù ứng viên khác.

Mỗi template: 6 câu thường + số câu zero ghi trong template (tổng 5 câu zero mỗi loại).
Loại ứng viên khi:
- trùng tham số với dev.json, dev_para.json, dev_zero.json, test.json cũ, câu pilot hoặc tên mẫu trong prompt (A)
  (so theo từng giá trị, không phân biệt hoa thường, '_' và dấu cách); forum có tiêu đề chứa họ tên đã dùng;
- thực thể đã dùng cho một câu khác của test2 (mỗi người / tag / thành phố… chỉ xuất hiện một lần);
- người trùng họ tên; gold lỗi hoặc quá 10 s; check không đạt; câu trùng;
- câu thường: đáp án rỗng/0/null, > 20 dòng hoặc có dòng trùng nhau. Câu zero: đáp án phải đúng là [] hoặc [[0]].

Chạy:  .venv/Scripts/python private/test2/build_test2.py      (từ thư mục DoAn, Neo4j đủ 327.588 node)
Ra:    private/test2/test2.json, private/test2/build_report.md, private/test2/doc_mu/…
"""
import json
import random
import sys
import zlib
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
sys.path.insert(0, str(ROOT / "eval"))

from neo4j import GraphDatabase  # noqa: E402

from generate_questions import AUTH, MAX_ROWS, SEED, URI, display, inline, pilot_entities, run, unique_person  # noqa: E402
from split_dev_test import canonical_hash  # noqa: E402

TEMPLATE_DIR = HERE / "templates"
OUT = HERE / "test2.json"
REPORT = HERE / "build_report.md"
BLIND_DIR = HERE / "doc_mu"
TYPES = ["lookup", "aggregation", "multi_hop", "path", "temporal"]
PER_TEMPLATE = 6
ZERO_PER_TYPE = 5
NOT_ENTITY = {"monthName", "month1Name", "month2Name"}
OLD_SPLITS = ["dev", "dev_para", "dev_zero", "test"]
# Quốc gia cần mạo từ "the" khi đứng trong câu
THE_COUNTRIES = {"United_States", "United_Kingdom", "Czech_Republic", "Netherlands", "Philippines",
                 "Dominican_Republic", "Democratic_Republic_of_the_Congo", "Republic_of_Ireland",
                 "Republic_of_Macedonia"}


def variants(value):
    s = str(value).strip().lower()
    return {s, s.replace(" ", "_"), s.replace("_", " ")}


def old_banned(driver):
    """Giá trị tham số (chữ thường) của các bộ câu cũ + pilot + tên mẫu của (A); họ tên đầy đủ đã dùng."""
    banned, full_names = set(), set()
    for split in OLD_SPLITS:
        path = ROOT / "eval" / "questions" / f"{split}.json"
        for q in json.loads(path.read_text(encoding="utf-8")):
            params = q.get("params", {})
            for k, v in params.items():
                if k not in NOT_ENTITY and isinstance(v, str):
                    banned |= variants(v)
            for s in ("", "1", "2"):
                if params.get("firstName" + s) and params.get("lastName" + s):
                    full_names.add(f"{params['firstName' + s]} {params['lastName' + s]}".lower())
    for v in pilot_entities():
        banned |= variants(v)
    # Tên mẫu trong prompt (A): chỉ lấy danh sách để tránh, không đọc nội dung prompt.
    try:
        import re
        from proposed.schema_a import sample_names
        for v in re.findall(r"'([^']+)'", sample_names(driver)):
            banned |= variants(v)
    except Exception as e:  # noqa: BLE001
        print("! không lấy được tên mẫu của (A):", e)
    return banned, full_names


def show(name, value):
    if name == "country" and value in THE_COUNTRIES:
        return "the " + display(value)
    return display(value)


def entity_keys(params):
    """Khóa thực thể của một câu: mỗi người là một khóa (họ, tên); giá trị chuỗi khác là một khóa."""
    keys, used = set(), set()
    for s in ("", "1", "2"):
        f, l = params.get("firstName" + s), params.get("lastName" + s)
        if f is not None and l is not None:
            keys.add(("person", f, l))
            used |= {"firstName" + s, "lastName" + s}
    for k, v in params.items():
        if k not in used and k not in NOT_ENTITY and isinstance(v, str):
            keys.add(("value", v.lower().replace("_", " ")))
    return keys


def is_zero_answer(rows):
    return rows == [] or rows == [[0]]


def bad_answer(rows):
    if not rows:
        return "empty"
    if len(rows) == 1 and len(rows[0]) == 1 and rows[0][0] in (0, None):
        return "zero"
    if any(v is None for r in rows for v in r):
        return "null_value"
    if len(rows) > MAX_ROWS:
        return "too_many_rows"
    if len({tuple(map(str, r)) for r in rows}) < len(rows):
        return "duplicate_rows"   # hai thực thể trùng tên: hệ thống dùng DISTINCT sẽ bị chấm sai oan
    return None


def generate(session, tpl, want, zero, banned, full_names, taken, usable):
    spec = tpl["zero"] if zero else tpl
    check = spec.get("check", tpl.get("check")) if zero else tpl.get("check")
    rng = random.Random(SEED + zlib.crc32((tpl["template_id"] + ("-zero" if zero else "")).encode()))
    candidates = [dict(zip(r.keys(), r.values())) for r in session.run(spec["candidates"], {"usable": usable})]
    rng.shuffle(candidates)
    kept, stats, seen = [], Counter(), set()
    # "prefer" (tùy chọn, chỉ câu thường): lượt 1 chỉ nhận ứng viên thỏa prefer, lượt 2 lấy bù phần còn thiếu.
    passes = [tpl["prefer"], None] if (not zero and "prefer" in tpl) else [None]
    for params, prefer in ((c, pf) for pf in passes for c in candidates):
        if len(kept) >= want:
            break
        keys = entity_keys(params)
        reason = None
        if any(isinstance(v, str) and k not in NOT_ENTITY and variants(v) & banned for k, v in params.items()):
            reason = "old_entity"
        elif "forum" in params and any(n in params["forum"].lower() for n in full_names):
            reason = "old_entity_in_title"
        elif keys & taken:
            reason = "used_in_test2"
        elif not unique_person(session, params):
            reason = "duplicate_name"
        rows = None
        if reason is None:
            try:
                rows = run(session, tpl["gold"], params)
                if zero:
                    reason = None if is_zero_answer(rows) else "not_zero"
                else:
                    reason = bad_answer(rows)
                if reason is None and check and not run(session, check, params)[0][0]:
                    reason = "check_failed"
                if reason is None and prefer and not run(session, prefer, params)[0][0]:
                    reason = "not_preferred"
            except Exception as e:  # noqa: BLE001  timeout hoặc lỗi Cypher
                reason = "error_or_timeout"
                msg = str(e).splitlines()[0][:100]
                if "timeout" not in msg.lower() and "terminated" not in msg.lower():
                    print(f"  {tpl['template_id']} lỗi: {msg}")
        phrasing = tpl["questions"][len(kept) % len(tpl["questions"])]
        question = phrasing.format(**{k: show(k, v) for k, v in params.items()})
        if reason is None and question in seen:
            reason = "duplicate_question"
        if reason:
            stats[reason] += 1
            continue
        seen.add(question)
        taken |= keys
        n = len(kept) + 1
        q = {
            "id": f"{tpl['template_id']}-{'Z' if zero else ''}{n:02d}",
            "template_id": tpl["template_id"],
            "type": tpl["type"],
            "question": question,
            "gold": inline(tpl["gold"], params),
            "params": params,
            "answer_preview": [[str(v) for v in row] for row in rows[:5]],
            "author": tpl.get("author", "Hương"),
            "checked_by": "",
            "note": spec["note"] if zero else "",
        }
        if zero:
            q["subset"] = "zero"
        kept.append(q)
    return kept, stats, len(candidates)


def main():
    with GraphDatabase.driver(URI, auth=AUTH) as driver:
        driver.verify_connectivity()
        banned, full_names = old_banned(driver)
        print(f"Giá trị bị cấm: {len(banned)}, họ tên đã dùng: {len(full_names)}")
        templates = {t: json.loads((TEMPLATE_DIR / f"{t}.json").read_text(encoding="utf-8")) for t in TYPES}
        taken, by_tpl, log = set(), defaultdict(dict), []
        with driver.session() as session:
            # Người dùng được: tên và họ đều chưa xuất hiện ở các bộ cũ (để ứng viên của template nhiều người đủ dùng).
            usable = [[f, l] for f, l in run(session, "MATCH (p:Person) RETURN p.firstName, p.lastName")
                      if not (variants(f) & banned or variants(l) & banned)]
            print(f"Người dùng được: {len(usable)}")
            # Câu zero trước vì ứng viên ít hơn.
            for zero in (True, False):
                for t in TYPES:
                    for tpl in templates[t]:
                        if zero and "zero" not in tpl:
                            continue
                        want = tpl["zero"]["count"] if zero else PER_TEMPLATE
                        kept, stats, n = generate(session, tpl, want, zero, banned, full_names, taken, usable)
                        by_tpl[tpl["template_id"]]["zero" if zero else "main"] = kept
                        line = (f"{tpl['template_id']} {'zero' if zero else 'main'}: giữ {len(kept)}/{want} "
                                f"(ứng viên {n}), loại {dict(stats) or '-'}")
                        print(" ", line)
                        log.append(line)
        questions = []
        for t in TYPES:
            for tpl in templates[t]:
                questions += by_tpl[tpl["template_id"]].get("main", [])
            for tpl in templates[t]:
                questions += by_tpl[tpl["template_id"]].get("zero", [])

    OUT.write_text(json.dumps(questions, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    count = Counter((q["type"], q.get("subset", "main")) for q in questions)
    lines = ["# Báo cáo sinh test2 (giữ kín)", "",
             f"- Tổng: **{len(questions)} câu**; sha256 (canonical_hash): `{canonical_hash(questions)}`", "",
             "| Loại | Câu thường | Câu zero |", "|---|---|---|"]
    lines += [f"| {t} | {count[(t, 'main')]} | {count[(t, 'zero')]} |" for t in TYPES]
    lines += ["", "## Nhật ký lọc theo template", "", "```", *log, "```", ""]
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(f"-> {OUT.relative_to(ROOT)} ({len(questions)} câu)")
    for t in TYPES:
        print(f"   {t}: {count[(t, 'main')]} + {count[(t, 'zero')]} zero")


if __name__ == "__main__":
    main()
